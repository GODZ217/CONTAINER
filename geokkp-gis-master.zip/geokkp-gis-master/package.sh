rm -f GeoKKP-GIS.zip && git archive --prefix=GeoKKP-GIS/ -o GeoKKP-GIS.zip HEAD
