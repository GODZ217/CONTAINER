import configparser
import os
import json
from pathlib import Path

from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import pyqtSignal
from qgis.utils import iface
from qgis.core import Qgis, QgsProject, QgsRectangle
from qgis.gui import QgsMessageBar

from .utils import (
    add_google_basemap,
    get_project_crs,
    set_project_crs_by_epsg,
    storeSetting,
    readSetting,
    dialogBox,
    get_saved_credentials,
    save_credentials,
    logMessage
)

from .api import endpoints
from .memo import app_state
from .postlogin import PostLoginDock
from .settings.settings_widgets import SettingsDialog
from .api import base

FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "../ui/login_otp.ui")
)


class LoginDialogOTP(QtWidgets.QDialog, FORM_CLASS):
    """Dialog for Login"""

    closingPlugin = pyqtSignal()
    loginChanged = pyqtSignal()

    def __init__(self, username, password, kantor, information,  parent=iface.mainWindow()):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        super(LoginDialogOTP, self).__init__(parent)
        self.setupUi(self)

        self.inputOTP.setMaxLength(6)

        self.kantor_data = kantor
        self.comboOtp.clear()
        index = 0
        try:
            storeSetting("jumlahkantor", len(kantor))
            storeSetting("listkantor", kantor)
            for i,data in enumerate(kantor):
                self.comboOtp.addItem(data["nama"])
                if(kantor and kantor == data["nama"]):
                    index = i
        except Exception:
            logMessage("Jumlah kantor tidak terbaca")
        self.comboOtp.setCurrentIndex(index)
        self.comboOtp.show()

        self.settingPage = SettingsDialog()
        self.bar = QgsMessageBar()

        name = information
        self.label_11.setText("Silahkan masuk untuk login, OTP Terkirim ke " + name)

        self.username = username
        self.password = password

        config = configparser.ConfigParser()
        config.read(os.path.join(os.path.dirname(__file__), "..", 'metadata.txt'))
        version = config.get('general', 'version')        
        self.teksVersi.setText("<p>Versi <a href='https://github.com/danylaksono/GeoKKP-GIS'> \
            <span style='text-decoration: underline; color:#009da5;'>" + version + "</span></a></p>")
        # login action
        self.buttonBoxLogin.clicked.connect(self.doTokenRequest)

    def _autofill_credentials(self):
        credentials = get_saved_credentials()
        if set(["username", "password"]).issubset(credentials.keys()):
            self.inputUsername.setText(credentials["username"])
            self.inputPassword.setText(credentials["password"])

    def showEvent(self, event):
        self._autofill_credentials()

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()

    def closedone(self):
        self.close()

    def doTokenRequest(self):
        """
        Login using requests
        API backend: {}/validateUser
        """
        username = self.username
        password = self.password
        otp = self.inputOTP.text()
        selected_nama = self.comboOtp.currentText()
        selected_item = next((item for item in self.kantor_data if item["nama"] == selected_nama), None)
        if selected_item:
            kantor = selected_item["kantorID"]
            app_state.set("kantor", selected_item)
        
        # logMessage(f"{username}, {password}")
        try:
            response = endpoints.validate(username, password, otp, kantor)
            content = json.loads(response.content)
            token = content["information"]

            if not content["status"]:
                dialogBox(
                    content["information"],
                )
            else:
                #set auth token to header
                base.DEFAULT_HEADER[b"Authorization"] = b"Bearer " + token.encode()
                # logMessage(str(content))
                self.iface.messageBar().pushMessage(
                    "Login Pengguna Berhasil:", username, level=Qgis.Success
                )
                self.loginChanged.emit()
                app_state.set("username", username)
                # self.getKantorProfile(username)
                # self.get_user(username)
                # daftarUser = readSetting("daftarUser")
                
                script_dir = Path(os.path.dirname(__file__)).parents[1]
                file_path = os.path.join(script_dir, 'file.json')
                try:
                    if(os.path.exists(file_path)):
                        # print(file_path,"file_path")
                        with open(file_path, "r") as outfile:
                            data = json.load(outfile)
                            # print(data,"datauser")
                        
                        result = [a for a in data["data_user"] if a["username"] == username]
                        if(len(result)==0):
                            self.settingPage.show()
                        else:
                            self.settingPage.get_pagawai(result[0]["kantor"])
                            self.settingPage.simpan_tm3(result[0]["tm3"])
                            self.postuserlogin()
                    else:
                        self.settingPage.show()
                except Exception as e:
                    self.settingPage.show()   

        except Exception as e:
            logMessage(str(e))
            dialogBox(
                "Kesalahan koneksi. Periksa sambungan Anda ke server GeoKKP",
                "Koneksi Bermasalah",
                "Warning",
            )

    def get_geo_profile(self, kantor_id):
        try:
            response = endpoints.get_is_e_sertifikat(kantor_id)
            is_e_sertifikat = response.content == "1"
            storeSetting("isESertifikat", is_e_sertifikat)
        except Exception as e:
            # print(e)
            dialogBox(
                "Gagal mengambil status data e-sertifikat dari server",
                "Koneksi Bermasalah",
                "Warning",
            )

    def get_user(self, username):
        response = endpoints.get_user_by_username(username)
        response_json = json.loads(response.content)
        # print("get_user_by_username", response_json)
        app_state.set("user", response_json)

    def getKantorProfile(self, username):
        """
        user entity
        API backend: {}/getEntityByUserName
        """
        try:
            response = endpoints.get_entity_by_username(username)
        except Exception as e:
            # print(e)
            dialogBox(
                "Data Pengguna gagal dimuat dari server",
                "Koneksi Bermasalah",
                "Warning",
            )

        if response is not None:
            response_json = json.loads(response.content)
            storeSetting("jumlahkantor", len(response_json))
            storeSetting("listkantor", response_json)
            if self.postlogin.populateKantah(response_json):
                self.postuserlogin()
        else:
            dialogBox(
                "Data Pengguna gagal disimpan ke dalam QGIS",
                "Koneksi Bermasalah",
                "Warning",
            )

    def postuserlogin(self,epsg = "EPSG:4326"):
        """
        what to do when user is logged in
        """   
        # print(get_project_crs())
        set_project_crs_by_epsg(epsg)
        rect = QgsRectangle(95.0146, -10.92107, 140.9771, 5.9101)
        self.iface.mapCanvas().setExtent(rect)
        self.iface.mapCanvas().refresh()
        self.accept()
        app_state.set("logged_in", True)

